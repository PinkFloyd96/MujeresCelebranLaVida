package com.ong.desktop.vistas;

import com.ong.desktop.modelos.Categoria;
import com.ong.desktop.modelos.Entidad;
import com.ong.desktop.modelos.Ubicacion;
import com.ong.desktop.modelos.Usuario;
import com.ong.desktop.servicios.ApiServicio;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.util.*;

public class FormularioDonacion {
    public interface AlGuardar { void guardar(Map<String, Object> datos); }

    public static void mostrar(Stage padre, com.ong.desktop.modelos.DonacionRecepcion existente, AlGuardar callback) {
        if (existente != null) {
            new Alert(Alert.AlertType.INFORMATION, "La edición de donaciones con artículos se habilitará después. Para no alterar el historial, por ahora solo se permite registrar una donación nueva.").showAndWait();
            return;
        }
        Stage ventana = new Stage();
        ventana.initModality(Modality.WINDOW_MODAL);
        ventana.initOwner(padre);
        ventana.setTitle("Registrar donación y artículos");

        ApiServicio api = new ApiServicio();
        ComboBox<Entidad> cmbDonante = new ComboBox<>();
        ComboBox<Usuario> cmbResponsable = new ComboBox<>();
        CheckBox chkNuevoDonante = new CheckBox("Registrar un donante nuevo");
        ComboBox<String> cmbTipoTercero = new ComboBox<>(FXCollections.observableArrayList("PERSONA", "FAMILIA", "INSTITUCION", "ORGANIZACION"));
        TextField txtNombre = new TextField(), txtDocumento = new TextField(), txtTelefono = new TextField(), txtDireccion = new TextField();
        TextArea txtObsDonante = new TextArea(); txtObsDonante.setPrefRowCount(2);
        TextArea txtObservaciones = new TextArea(); txtObservaciones.setPrefRowCount(2);

        ComboBox<Categoria> cmbCategoria = new ComboBox<>();
        Button btnNuevaCategoria = new Button("+ Nueva");
        btnNuevaCategoria.setOnAction(ev -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Nueva categoría"); dialog.setHeaderText("Crear categoría"); dialog.setContentText("Nombre:");
            dialog.showAndWait().ifPresent(nombre -> {
                if (nombre == null || nombre.isBlank()) { new Alert(Alert.AlertType.WARNING, "Ingresá un nombre para la categoría.").showAndWait(); return; }
                try {
                    Categoria nueva = new Categoria(); nueva.setNombre(nombre.trim()); nueva.setDescripcion("");
                    Categoria guardada = api.crearCategoria(nueva);
                    cmbCategoria.getItems().setAll(api.listarCategorias());
                    cmbCategoria.getItems().stream().filter(c -> c.getIdCategoria() != null && c.getIdCategoria().equals(guardada.getIdCategoria())).findFirst().ifPresent(cmbCategoria::setValue);
                } catch (Exception ex) { new Alert(Alert.AlertType.ERROR, "No se pudo crear la categoría. " + ex.getMessage()).showAndWait(); }
            });
        });
        HBox categoriaBox = new HBox(6, cmbCategoria, btnNuevaCategoria);
        ComboBox<Ubicacion> cmbUbicacion = new ComboBox<>();
        TextField txtCodigo = new TextField(), txtDescripcion = new TextField(), txtMarca = new TextField(), txtModelo = new TextField(), txtSerie = new TextField();
        ComboBox<String> cmbCondicion = new ComboBox<>(FXCollections.observableArrayList("BUENO", "REGULAR", "MALO", "REPARACION"));
        ComboBox<String> cmbControl = new ComboBox<>(FXCollections.observableArrayList("CANTIDAD", "INDIVIDUAL"));
        TextField txtCantidad = new TextField("1");
        TextArea txtObsArticulo = new TextArea(); txtObsArticulo.setPrefRowCount(1);
        TableView<ItemDonacion> tablaItems = new TableView<>();
        tablaItems.setPrefHeight(150);
        TableColumn<ItemDonacion, String> cCodigo = new TableColumn<>("Código"); cCodigo.setCellValueFactory(new PropertyValueFactory<>("codigo"));
        TableColumn<ItemDonacion, String> cDesc = new TableColumn<>("Artículo"); cDesc.setCellValueFactory(new PropertyValueFactory<>("descripcion")); cDesc.setPrefWidth(180);
        TableColumn<ItemDonacion, String> cTipo = new TableColumn<>("Control"); cTipo.setCellValueFactory(new PropertyValueFactory<>("tipoControl"));
        TableColumn<ItemDonacion, Integer> cCantidad = new TableColumn<>("Cantidad"); cCantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
        TableColumn<ItemDonacion, String> cCategoria = new TableColumn<>("Categoría"); cCategoria.setCellValueFactory(new PropertyValueFactory<>("categoria"));
        tablaItems.getColumns().addAll(cCodigo, cDesc, cTipo, cCantidad, cCategoria);
        List<ItemDonacion> items = new ArrayList<>();

        try {
            cmbDonante.getItems().setAll(api.listarEntidades());
            cmbResponsable.getItems().setAll(api.listarUsuarios());
            cmbCategoria.getItems().setAll(api.listarCategorias());
            cmbUbicacion.getItems().setAll(api.listarUbicaciones());
        } catch (Exception e) {
            new Alert(Alert.AlertType.ERROR, "No se pudieron cargar donantes, usuarios, categorías o ubicaciones. Verificá que la API esté iniciada.\n" + e.getMessage()).showAndWait();
        }
        cmbDonante.setPromptText("Seleccionar donante existente"); cmbResponsable.setPromptText("Responsable de recepción");
        cmbCategoria.setPromptText("Categoría"); cmbUbicacion.setPromptText("Ubicación actual");
        cmbCondicion.setValue("BUENO"); cmbControl.setValue("CANTIDAD"); cmbTipoTercero.setValue("PERSONA");
        txtCodigo.setPromptText("Ej. ELE-001"); txtDescripcion.setPromptText("Nombre o descripción del artículo"); txtCantidad.setPromptText("Cantidad");

        GridPane datosDonante = new GridPane(); datosDonante.setHgap(8); datosDonante.setVgap(7);
        datosDonante.add(new Label("Donante existente:"),0,0); datosDonante.add(cmbDonante,1,0,3,1);
        datosDonante.add(new Label("Tipo:"),0,1); datosDonante.add(cmbTipoTercero,1,1);
        datosDonante.add(new Label("Nombre *:"),2,1); datosDonante.add(txtNombre,3,1);
        datosDonante.add(new Label("Documento:"),0,2); datosDonante.add(txtDocumento,1,2);
        datosDonante.add(new Label("Teléfono:"),2,2); datosDonante.add(txtTelefono,3,2);
        datosDonante.add(new Label("Dirección:"),0,3); datosDonante.add(txtDireccion,1,3,3,1);
        datosDonante.add(new Label("Observaciones del donante:"),0,4); datosDonante.add(txtObsDonante,1,4,3,1);
        chkNuevoDonante.selectedProperty().addListener((o,a,n)->{
            cmbDonante.setDisable(n); cmbDonante.setVisible(!n); cmbDonante.setManaged(!n);
            for (javafx.scene.Node node : datosDonante.getChildren()) {
                Integer col=GridPane.getColumnIndex(node), row=GridPane.getRowIndex(node);
                if (row != null && row >= 1) { node.setVisible(n); node.setManaged(n); }
            }
            // El título de la fila inicial sigue disponible para seleccionar un donante existente.
            datosDonante.getChildren().stream().filter(node -> node instanceof Label l && l.getText().equals("Donante existente:")).forEach(node -> {node.setVisible(!n);node.setManaged(!n);});
        });
        datosDonante.getChildren().stream().filter(node -> {Integer r=GridPane.getRowIndex(node); return r!=null && r>=1;}).forEach(node->{node.setVisible(false);node.setManaged(false);});

        GridPane datosArticulo = new GridPane(); datosArticulo.setHgap(8); datosArticulo.setVgap(7);
        datosArticulo.add(new Label("Código inventario *:"),0,0); datosArticulo.add(txtCodigo,1,0);
        datosArticulo.add(new Label("Descripción *:"),2,0); datosArticulo.add(txtDescripcion,3,0);
        datosArticulo.add(new Label("Categoría *:"),0,1); datosArticulo.add(categoriaBox,1,1);
        datosArticulo.add(new Label("Ubicación *:"),2,1); datosArticulo.add(cmbUbicacion,3,1);
        datosArticulo.add(new Label("Marca:"),0,2); datosArticulo.add(txtMarca,1,2);
        datosArticulo.add(new Label("Modelo:"),2,2); datosArticulo.add(txtModelo,3,2);
        datosArticulo.add(new Label("N.º serie:"),0,3); datosArticulo.add(txtSerie,1,3);
        datosArticulo.add(new Label("Condición:"),2,3); datosArticulo.add(cmbCondicion,3,3);
        datosArticulo.add(new Label("Tipo de control:"),0,4); datosArticulo.add(cmbControl,1,4);
        datosArticulo.add(new Label("Cantidad *:"),2,4); datosArticulo.add(txtCantidad,3,4);
        datosArticulo.add(new Label("Observaciones:"),0,5); datosArticulo.add(txtObsArticulo,1,5,3,1);
        cmbControl.valueProperty().addListener((o,a,n)->{if("INDIVIDUAL".equals(n)) txtCantidad.setText("1"); txtCantidad.setDisable("INDIVIDUAL".equals(n));});

        Button btnAgregar = new Button("Agregar artículo a la donación");
        Button btnQuitar = new Button("Quitar seleccionado");
        btnAgregar.setOnAction(e->{
            try {
                if (txtCodigo.getText().isBlank() || txtDescripcion.getText().isBlank()) throw new IllegalArgumentException("Completá el código y la descripción del artículo.");
                if (cmbCategoria.getValue()==null || cmbUbicacion.getValue()==null) throw new IllegalArgumentException("Seleccioná categoría y ubicación.");
                int cantidad=Integer.parseInt(txtCantidad.getText().trim());
                if(cantidad<1) throw new IllegalArgumentException("La cantidad debe ser al menos 1.");
                if("INDIVIDUAL".equals(cmbControl.getValue()) && cantidad!=1) throw new IllegalArgumentException("Un artículo con control individual debe registrarse con cantidad 1.");
                if(items.stream().anyMatch(i->i.codigo.equalsIgnoreCase(txtCodigo.getText().trim()))) throw new IllegalArgumentException("Ya agregaste un artículo con ese código a esta donación.");
                ItemDonacion item=new ItemDonacion(txtCodigo.getText().trim(),txtDescripcion.getText().trim(),cmbCategoria.getValue().getIdCategoria(),cmbCategoria.getValue().getNombre(),cmbUbicacion.getValue().getIdUbicacion(),txtMarca.getText().trim(),txtModelo.getText().trim(),txtSerie.getText().trim(),cmbCondicion.getValue(),cmbControl.getValue(),cantidad,txtObsArticulo.getText().trim());
                items.add(item); tablaItems.getItems().setAll(items);
                txtCodigo.clear(); txtDescripcion.clear(); txtMarca.clear(); txtModelo.clear(); txtSerie.clear(); txtObsArticulo.clear(); txtCantidad.setText("1");
            } catch(Exception ex){new Alert(Alert.AlertType.WARNING,"Revisá los datos del artículo:\n"+ex.getMessage()).showAndWait();}
        });
        btnQuitar.setOnAction(e->{ItemDonacion sel=tablaItems.getSelectionModel().getSelectedItem();if(sel!=null){items.remove(sel);tablaItems.getItems().setAll(items);}});

        VBox contenido = new VBox(10);
        contenido.setPadding(new Insets(16));
        Label tituloDonante = new Label("1. Datos de la donación"); tituloDonante.setStyle("-fx-font-size: 15px; -fx-font-weight: bold;");
        Label tituloArticulos = new Label("2. Artículos recibidos"); tituloArticulos.setStyle("-fx-font-size: 15px; -fx-font-weight: bold;");
        Label tituloLista = new Label("Artículos que se registrarán en esta donación");
        HBox botonesItems = new HBox(8,btnAgregar,btnQuitar);
        contenido.getChildren().addAll(tituloDonante,chkNuevoDonante,datosDonante,new Label("Responsable de recepción *:"),cmbResponsable,new Label("Observaciones generales:"),txtObservaciones,tituloArticulos,datosArticulo,botonesItems,tituloLista,tablaItems);
        ScrollPane scroll = new ScrollPane(contenido); scroll.setFitToWidth(true);
        Button btnGuardar = new Button("Guardar donación completa"); Button btnCancelar = new Button("Cancelar");
        HBox acciones = new HBox(10,btnGuardar,btnCancelar); acciones.setAlignment(Pos.CENTER_RIGHT); acciones.setPadding(new Insets(10,16,14,16));
        btnCancelar.setOnAction(e->ventana.close());
        btnGuardar.setOnAction(e->{
            try {
                if(cmbResponsable.getValue()==null) throw new IllegalArgumentException("Seleccioná quién recibe la donación.");
                if(chkNuevoDonante.isSelected() && txtNombre.getText().isBlank()) throw new IllegalArgumentException("Ingresá el nombre del nuevo donante.");
                if(!chkNuevoDonante.isSelected() && cmbDonante.getValue()==null) throw new IllegalArgumentException("Seleccioná un donante o marcá la opción para registrar uno nuevo.");
                if(items.isEmpty()) throw new IllegalArgumentException("Agregá al menos un artículo a la donación.");
                Map<String,Object> payload=new LinkedHashMap<>();
                payload.put("idUsuario",cmbResponsable.getValue().getIdUsuario());
                payload.put("fechaDonacion", LocalDate.now().toString()); payload.put("observaciones",txtObservaciones.getText().trim());
                if(chkNuevoDonante.isSelected()){
                    Map<String,Object> donante=new LinkedHashMap<>(); donante.put("nombre",txtNombre.getText().trim()); donante.put("tipoTercero",cmbTipoTercero.getValue()); donante.put("documento",txtDocumento.getText().trim()); donante.put("telefono",txtTelefono.getText().trim()); donante.put("direccion",txtDireccion.getText().trim()); donante.put("observaciones",txtObsDonante.getText().trim()); payload.put("nuevoDonante",donante);
                } else payload.put("idTercero",cmbDonante.getValue().getIdEntidad());
                List<Map<String,Object>> lineas=new ArrayList<>();
                for(ItemDonacion i:items){Map<String,Object> m=new LinkedHashMap<>();m.put("codigoInventario",i.codigo);m.put("descripcion",i.descripcion);m.put("idCategoria",i.idCategoria);m.put("idUbicacion",i.idUbicacion);m.put("marca",i.marca);m.put("modelo",i.modelo);m.put("numeroSerie",i.numeroSerie);m.put("condicion",i.condicion);m.put("tipoControl",i.tipoControl);m.put("cantidad",i.cantidad);m.put("observaciones",i.observaciones);lineas.add(m);}
                payload.put("articulos",lineas); callback.guardar(payload); ventana.close();
            }catch(Exception ex){new Alert(Alert.AlertType.WARNING,"No se puede guardar la donación:\n"+ex.getMessage()).showAndWait();}
        });
        BorderPane root=new BorderPane();root.setCenter(scroll);root.setBottom(acciones);
        ventana.setScene(new Scene(root,900,760));ventana.showAndWait();
    }

    public static class ItemDonacion {
        private final String codigo,descripcion,categoria,marca,modelo,numeroSerie,condicion,tipoControl,observaciones;
        private final Integer idCategoria,idUbicacion,cantidad;
        ItemDonacion(String codigo,String descripcion,Integer idCategoria,String categoria,Integer idUbicacion,String marca,String modelo,String numeroSerie,String condicion,String tipoControl,Integer cantidad,String observaciones){this.codigo=codigo;this.descripcion=descripcion;this.idCategoria=idCategoria;this.categoria=categoria;this.idUbicacion=idUbicacion;this.marca=marca;this.modelo=modelo;this.numeroSerie=numeroSerie;this.condicion=condicion;this.tipoControl=tipoControl;this.cantidad=cantidad;this.observaciones=observaciones;}
        public String getCodigo(){return codigo;} public String getDescripcion(){return descripcion;} public String getCategoria(){return categoria;} public String getTipoControl(){return tipoControl;} public Integer getCantidad(){return cantidad;}
    }
}
