package com.ong.desktop;

import com.ong.desktop.modelos.Usuario;
import com.ong.desktop.vistas.*;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class App extends Application {
    private BorderPane root;
    private VBox menuLateral;
    private Button botonActivo;
    private Stage stageActual;
    private Usuario usuarioActual;

    @Override public void start(Stage stage) {
        VentanaLogin.mostrar(stage, usuario -> construirAppPrincipal(stage, usuario));
    }

    private void construirAppPrincipal(Stage stage, Usuario usuario) {
        this.stageActual=stage; this.usuarioActual=usuario;
        root = new BorderPane();
        root.setStyle("-fx-background-color:#fbf7fa;");
        ImageView logo = new ImageView();
        try { logo.setImage(new Image(getClass().getResourceAsStream("/logo.png"))); logo.setFitHeight(42); logo.setPreserveRatio(true); }
        catch (Exception ignored) { }

        Label titulo = new Label("Mujeres Celebran la Vida");
        titulo.setStyle("-fx-font-size:16px;-fx-font-weight:bold;-fx-text-fill:white;");
        Label rolLabel = new Label(etiquetaRol(usuario.getRol())); rolLabel.setStyle("-fx-text-fill:#ffe5f2;-fx-font-size:11px;");
        VBox marca = new VBox(2,titulo,rolLabel);
        Button btnCerrarSesion = new Button("Cerrar sesión");
        btnCerrarSesion.setStyle("-fx-background-color:#a02060;-fx-text-fill:white;-fx-font-size:12px;-fx-padding:8px 15px;-fx-cursor:hand;-fx-background-radius:5px;");
        btnCerrarSesion.setOnAction(e -> {
            Alert c=new Alert(Alert.AlertType.CONFIRMATION); c.setTitle("Cerrar sesión"); c.setHeaderText("¿Querés cerrar la sesión?"); c.setContentText("Volverás a la pantalla de acceso.");
            c.showAndWait().ifPresent(r->{if(r==ButtonType.OK){stage.close();Stage nuevo=new Stage();VentanaLogin.mostrar(nuevo,u->construirAppPrincipal(nuevo,u));}});
        });
        Region spacer=new Region(); HBox.setHgrow(spacer,Priority.ALWAYS);
        HBox top=new HBox(14,logo,marca,spacer,btnCerrarSesion); top.setAlignment(Pos.CENTER_LEFT); top.setPadding(new Insets(10,20,10,20)); top.setStyle("-fx-background-color:#7a2859;"); root.setTop(top);

        menuLateral=new VBox(7); menuLateral.setPadding(new Insets(16,10,16,10)); menuLateral.setPrefWidth(205); menuLateral.setStyle("-fx-background-color:#f5edf2;-fx-border-color:#eadce5;-fx-border-width:0 1px 0 0;");
        Label principal=grupo("PRINCIPAL"); menuLateral.getChildren().add(principal);
        agregarMenu("⌂  Inicio","dashboard");
        agregarMenu("📦  Inventario","articulos");
        menuLateral.getChildren().add(grupo("OPERACIONES"));
        agregarMenu("💝  Donaciones","donaciones");
        agregarMenu("🤝  Préstamos","prestamos");
        agregarMenu("🎁  Entregas definitivas","entregas");
        agregarMenu("📌  Reservas","reservas");
        menuLateral.getChildren().add(grupo("SEGUIMIENTO"));
        agregarMenu("🧾  Historial","historial");
        agregarMenu("📊  Reportes","reportes");
        if ("ADMINISTRADOR".equalsIgnoreCase(usuario.getRol()) || "RESPONSABLE_INVENTARIO".equalsIgnoreCase(usuario.getRol())) {
            menuLateral.getChildren().add(grupo("MANTENIMIENTO")); agregarMenu("⚙  Configuración","administracion");
        }
        root.setLeft(menuLateral);
        mostrarDestino("dashboard");
        Scene scene=new Scene(root,1250,780);
        try { scene.getStylesheets().add(getClass().getResource("/estilos.css").toExternalForm()); } catch(Exception ignored) { }
        stage.setTitle("Mujeres Celebran la Vida · Inventario"); stage.setMinWidth(1050); stage.setMinHeight(680); stage.setScene(scene); stage.show();
    }

    private Label grupo(String texto) { Label l=new Label(texto); l.setStyle("-fx-font-size:10px;-fx-font-weight:bold;-fx-text-fill:#94788a;-fx-padding:8px 8px 2px 8px;"); return l; }
    private void agregarMenu(String texto,String destino) {
        Button b=new Button(texto); b.setMaxWidth(Double.MAX_VALUE); b.setAlignment(Pos.CENTER_LEFT); b.setWrapText(true); b.setMinHeight(37);
        b.setStyle(estiloMenu(false)); b.setOnAction(e->{marcarActivo(b);mostrarDestino(destino);}); menuLateral.getChildren().add(b);
        if (destino.equals("dashboard")) { botonActivo=b; }
    }
    private void marcarActivo(Button b) {
        for (javafx.scene.Node n:menuLateral.getChildren()) if(n instanceof Button btn) btn.setStyle(estiloMenu(btn==b)); botonActivo=b;
    }
    private String estiloMenu(boolean activo) { return activo ? "-fx-background-color:#d63384;-fx-text-fill:white;-fx-font-weight:bold;-fx-background-radius:8px;-fx-padding:9px 10px;" : "-fx-background-color:transparent;-fx-text-fill:#59394d;-fx-background-radius:8px;-fx-padding:9px 10px;-fx-cursor:hand;"; }
    private String etiquetaRol(String r) { if(r==null)return "Acceso de consulta"; return switch(r.toUpperCase()) {case "ADMINISTRADOR"->"Administración";case "RESPONSABLE_INVENTARIO"->"Responsable de inventario";case "USUARIO_OPERATIVO"->"Usuario operativo";default->"Acceso de consulta";}; }

    private void mostrarDestino(String tipo) {
        if (root==null) return;
        String rol=usuarioActual.getRol()==null?"CONSULTA":usuarioActual.getRol();
        switch(tipo) {
            case "dashboard": root.setCenter(new PanelDashboard(stageActual,usuarioActual,this::navegar).construir()); break;
            case "articulos": root.setCenter(new PanelArticulos(stageActual,rol,usuarioActual.getIdUsuario()).construir()); break;
            case "articulo_nuevo": { PanelArticulos p=new PanelArticulos(stageActual,rol,usuarioActual.getIdUsuario()); root.setCenter(p.construir()); if(!"CONSULTA".equalsIgnoreCase(rol)) p.abrirNuevoArticulo(); break; }
            case "donaciones": root.setCenter(new PanelDonaciones(stageActual,rol).construir()); break;
            case "donacion_nueva": { PanelDonaciones p=new PanelDonaciones(stageActual,rol); root.setCenter(p.construir()); if(!"CONSULTA".equalsIgnoreCase(rol)) p.abrirNuevaDonacion(); break; }
            case "prestamos": root.setCenter(new PanelPrestamos(stageActual,rol).construir()); break;
            case "prestamo_nuevo": { PanelPrestamos p=new PanelPrestamos(stageActual,rol); root.setCenter(p.construir()); if(!"CONSULTA".equalsIgnoreCase(rol)) p.abrirNuevoPrestamo(); break; }
            case "entregas": root.setCenter(new PanelEntregas(stageActual,rol).construir()); break;
            case "entrega_nueva": { PanelEntregas p=new PanelEntregas(stageActual,rol); root.setCenter(p.construir()); if(!"CONSULTA".equalsIgnoreCase(rol)) p.abrirNuevaEntrega(); break; }
            case "reservas": root.setCenter(new PanelReservas(stageActual,rol,usuarioActual.getIdUsuario()).construir()); break;
            case "reserva_nueva": { PanelReservas p=new PanelReservas(stageActual,rol,usuarioActual.getIdUsuario()); root.setCenter(p.construir()); if(!"CONSULTA".equalsIgnoreCase(rol)) p.abrirNuevaReserva(); break; }
            case "historial": root.setCenter(new PanelHistorial(stageActual,rol).construir()); break;
            case "reportes": root.setCenter(new PanelReportes(stageActual).construir()); break;
            case "administracion": root.setCenter(new PanelAdministracion(stageActual,rol,this::navegar).construir()); break;
            case "categorias": root.setCenter(new PanelCategorias(stageActual,rol).construir()); break;
            case "ubicaciones": root.setCenter(new PanelUbicaciones(stageActual,rol).construir()); break;
            case "entidades": root.setCenter(new PanelEntidades(stageActual,rol).construir()); break;
            case "usuarios": root.setCenter(new PanelUsuarios(stageActual,rol).construir()); break;
            default: new Alert(Alert.AlertType.INFORMATION,"Esta operación todavía no tiene una pantalla independiente.").showAndWait();
        }
    }
    private void navegar(String destino) {
        for (javafx.scene.Node n:menuLateral.getChildren()) if(n instanceof Button b) {
            String texto=b.getText();
            boolean activo = switch(destino) {
                case "dashboard" -> texto.contains("Inicio"); case "articulos" -> texto.contains("Inventario"); case "donaciones" -> texto.contains("Donaciones");
                case "prestamos" -> texto.contains("Préstamos"); case "entregas" -> texto.contains("Entregas"); case "reservas" -> texto.contains("Reservas");
                case "historial" -> texto.contains("Historial"); case "reportes" -> texto.contains("Reportes"); case "administracion","categorias","ubicaciones","entidades","usuarios" -> texto.contains("Configuración"); default -> false;
            }; if(activo) marcarActivo(b);
        }
        mostrarDestino(destino);
    }
    public static void main(String[] args) { launch(args); }
}
