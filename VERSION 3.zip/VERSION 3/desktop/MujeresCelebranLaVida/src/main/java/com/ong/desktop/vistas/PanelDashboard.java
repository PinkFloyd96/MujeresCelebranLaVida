package com.ong.desktop.vistas;

import com.ong.desktop.modelos.Articulo;
import com.ong.desktop.modelos.DonacionRecepcion;
import com.ong.desktop.modelos.Usuario;
import com.ong.desktop.servicios.ApiServicio;
import com.ong.desktop.servicios.Notificaciones;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Popup;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** Panel principal orientado a las operaciones cotidianas de la ONG. */
public class PanelDashboard {
    private final ApiServicio api = new ApiServicio();
    private final Stage owner;
    private final Usuario usuario;
    private final Consumer<String> navegar;

    public PanelDashboard(Stage owner, Usuario usuario, Consumer<String> navegar) {
        this.owner = owner;
        this.usuario = usuario;
        this.navegar = navegar;
    }

    public VBox construir() {
        VBox panel = new VBox(22);
        panel.setPadding(new Insets(28));
        panel.setStyle("-fx-background-color: #fbf7fa;");

        HBox encabezado = new HBox(12);
        encabezado.setAlignment(Pos.CENTER_LEFT);
        VBox saludo = new VBox(4);
        Label titulo = new Label("Buen día, " + nombreUsuario() + " 💗");
        titulo.setFont(Font.font("System", FontWeight.BOLD, 25));
        titulo.setStyle("-fx-text-fill: #51233f;");
        Label subtitulo = new Label("Mujeres Celebran la Vida · Gestión de inventario y donaciones");
        subtitulo.setStyle("-fx-text-fill: #766572; -fx-font-size: 13px;");
        saludo.getChildren().addAll(titulo, subtitulo);
        Region espacio = new Region(); HBox.setHgrow(espacio, Priority.ALWAYS);
        Button btnNotificaciones = new Button("🔔 Alertas");
        btnNotificaciones.setStyle(estiloSecundario());
        List<Notificaciones.Alerta> alertas = obtenerAlertas();
        btnNotificaciones.setOnAction(e -> mostrarNotificaciones(btnNotificaciones, alertas));
        encabezado.getChildren().addAll(saludo, espacio, btnNotificaciones);

        HBox resumen = new HBox(14);
        resumen.getChildren().addAll(
            tarjetaResumen("Artículos registrados", contarArticulos(), "📦"),
            tarjetaResumen("Donaciones", contarDonaciones(), "💝"),
            tarjetaResumen("Alertas de stock", String.valueOf(alertas.size()), "⚠️")
        );
        for (Node n : resumen.getChildren()) HBox.setHgrow(n, Priority.ALWAYS);

        Label accionesTitulo = new Label("¿Qué necesitás hacer hoy?");
        accionesTitulo.setFont(Font.font("System", FontWeight.BOLD, 19));
        accionesTitulo.setStyle("-fx-text-fill: #51233f;");
        Label accionesSub = new Label("Accesos directos a las tareas más frecuentes. Los datos de configuración están agrupados aparte.");
        accionesSub.setWrapText(true); accionesSub.setStyle("-fx-text-fill: #766572; -fx-font-size: 12px;");

        TilePane acciones = new TilePane();
        acciones.setHgap(14); acciones.setVgap(14); acciones.setPrefTileWidth(230); acciones.setPrefTileHeight(116);
        acciones.setAlignment(Pos.TOP_LEFT);
        if (!esConsulta()) acciones.getChildren().add(accion("💝", "Registrar donación", "Recibir artículos y actualizar stock", "donacion_nueva", true));
        acciones.getChildren().add(accion("📦", "Consultar inventario", "Buscar artículos, cantidades y estados", "articulos", false));
        if (!esConsulta()) acciones.getChildren().add(accion("➕", "Registrar artículo", "Dar de alta un artículo con categoría y ubicación", "articulo_nuevo", false));
        if (!esConsulta()) acciones.getChildren().add(accion("🤝", "Registrar préstamo", "Registrar responsable, destinatario y devolución prevista", "prestamo_nuevo", true));
        if (!esConsulta()) acciones.getChildren().add(accion("↩️", "Registrar devolución", "Seleccionar un préstamo activo y registrar el retorno", "prestamos", false));
        if (!esConsulta()) acciones.getChildren().add(accion("🎁", "Registrar entrega", "Registrar entrega definitiva a una persona u organización", "entrega_nueva", true));
        if (!esConsulta()) acciones.getChildren().add(accion("📌", "Nueva reserva", "Apartar artículos sin descontarlos del stock disponible", "reserva_nueva", false));
        acciones.getChildren().add(accion("🧾", "Historial de movimientos", "Trazabilidad de ingresos y salidas", "historial", false));
        acciones.getChildren().add(accion("📊", "Reportes", "Consultar y exportar información", "reportes", false));
        if (esAdministrador() || esResponsable()) acciones.getChildren().add(accion("⚙️", "Configuración", "Donantes, categorías, ubicaciones y usuarios", "administracion", false));

        panel.getChildren().addAll(encabezado, resumen, accionesTitulo, accionesSub, acciones);
        return panel;
    }

    private String nombreUsuario() {
        if (usuario == null || usuario.getNombre() == null || usuario.getNombre().isBlank()) return "bienvenida";
        return usuario.getNombre().trim();
    }
    private boolean esConsulta() { return "CONSULTA".equalsIgnoreCase(usuario == null ? null : usuario.getRol()); }
    private boolean esAdministrador() { return "ADMINISTRADOR".equalsIgnoreCase(usuario == null ? null : usuario.getRol()); }
    private boolean esResponsable() { return "RESPONSABLE_INVENTARIO".equalsIgnoreCase(usuario == null ? null : usuario.getRol()); }

    private String contarArticulos() { try { return String.valueOf(api.listarArticulos().size()); } catch (Exception e) { return "—"; } }
    private String contarDonaciones() { try { return String.valueOf(api.listarDonaciones().size()); } catch (Exception e) { return "—"; } }
    private List<Notificaciones.Alerta> obtenerAlertas() {
        try { List<Articulo> articulos = api.listarArticulos(); return Notificaciones.calcular(articulos); }
        catch (Exception e) { return new ArrayList<>(); }
    }

    private VBox tarjetaResumen(String titulo, String valor, String emoji) {
        VBox card = new VBox(8); card.setPadding(new Insets(16)); card.setMinHeight(100);
        card.setStyle("-fx-background-color: white; -fx-background-radius: 13px; -fx-border-color: #eee1e9; -fx-border-radius: 13px;");
        Label icono = new Label(emoji); icono.setStyle("-fx-font-size: 21px;");
        Label numero = new Label(valor); numero.setFont(Font.font("System", FontWeight.BOLD, 23)); numero.setStyle("-fx-text-fill: #a12c70;");
        Label etiqueta = new Label(titulo); etiqueta.setStyle("-fx-text-fill: #766572; -fx-font-size: 12px;");
        card.getChildren().addAll(icono, numero, etiqueta); return card;
    }

    private VBox accion(String emoji, String titulo, String descripcion, String destino, boolean principal) {
        VBox card = new VBox(8); card.setPadding(new Insets(16)); card.setMinHeight(112); card.setMaxWidth(260);
        card.setStyle(principal
            ? "-fx-background-color: #fff; -fx-background-radius: 13px; -fx-border-color: #d63384; -fx-border-width: 1.5px; -fx-border-radius: 13px; -fx-cursor: hand;"
            : "-fx-background-color: white; -fx-background-radius: 13px; -fx-border-color: #eee1e9; -fx-border-radius: 13px; -fx-cursor: hand;");
        Label icono = new Label(emoji); icono.setStyle("-fx-font-size: 24px;");
        Label nombre = new Label(titulo); nombre.setFont(Font.font("System", FontWeight.BOLD, 14)); nombre.setStyle("-fx-text-fill: #51233f;");
        Label detalle = new Label(descripcion); detalle.setWrapText(true); detalle.setStyle("-fx-text-fill: #766572; -fx-font-size: 11px;");
        card.getChildren().addAll(icono, nombre, detalle);
        card.setOnMouseClicked(e -> navegar.accept(destino));
        card.setOnMouseEntered(e -> card.setStyle("-fx-background-color: #fff5fa; -fx-background-radius: 13px; -fx-border-color: #d63384; -fx-border-width: 1.5px; -fx-border-radius: 13px; -fx-cursor: hand;"));
        card.setOnMouseExited(e -> card.setStyle(principal
            ? "-fx-background-color: #fff; -fx-background-radius: 13px; -fx-border-color: #d63384; -fx-border-width: 1.5px; -fx-border-radius: 13px; -fx-cursor: hand;"
            : "-fx-background-color: white; -fx-background-radius: 13px; -fx-border-color: #eee1e9; -fx-border-radius: 13px; -fx-cursor: hand;"));
        return card;
    }

    private String estiloSecundario() { return "-fx-background-color: white; -fx-text-fill: #7a2859; -fx-border-color: #ead3e1; -fx-border-radius: 8px; -fx-background-radius: 8px; -fx-padding: 9px 13px;"; }

    private void mostrarNotificaciones(Node ancla, List<Notificaciones.Alerta> alertas) {
        Popup popup = new Popup(); popup.setAutoHide(true);
        VBox contenido = new VBox(10); contenido.setPadding(new Insets(15)); contenido.setMaxWidth(380); contenido.setMaxHeight(500);
        contenido.setStyle("-fx-background-color: white; -fx-background-radius: 10px; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.22), 15, 0, 0, 5);");
        Label titulo = new Label("Alertas de inventario"); titulo.setFont(Font.font("System", FontWeight.BOLD, 16)); titulo.setStyle("-fx-text-fill: #a12c70;"); contenido.getChildren().add(titulo);
        if (alertas.isEmpty()) { contenido.getChildren().add(new Label("No hay alertas de stock en este momento.")); }
        else {
            ScrollPane scroll = new ScrollPane(); VBox lista = new VBox(8); lista.setPadding(new Insets(5));
            for (Notificaciones.Alerta a : alertas) {
                VBox item = new VBox(3); item.setPadding(new Insets(9)); item.setStyle("-fx-background-color: #fbf7fa; -fx-background-radius: 8px; -fx-border-color: " + a.color + "; -fx-border-width: 0 0 0 4px;");
                Label t = new Label(a.icono + "  " + a.titulo); t.setStyle("-fx-font-weight: bold; -fx-text-fill: #51233f;");
                Label d = new Label(a.detalle); d.setWrapText(true); d.setStyle("-fx-text-fill: #766572; -fx-font-size: 11px;"); item.getChildren().addAll(t,d); lista.getChildren().add(item);
            }
            scroll.setContent(lista); scroll.setFitToWidth(true); scroll.setPrefHeight(Math.min(400, alertas.size()*65+20)); contenido.getChildren().add(scroll);
        }
        popup.getContent().add(contenido);
        javafx.geometry.Bounds bounds = ancla.localToScreen(ancla.getBoundsInLocal());
        if (bounds != null) popup.show(ancla, bounds.getMaxX()-contenido.getWidth(), bounds.getMaxY()+5);
    }
}
