package com.ong.desktop.vistas;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import java.util.function.Consumer;

/** Agrupa catálogos y configuración que se usan con menos frecuencia. */
public class PanelAdministracion {
    private final Stage owner;
    private final String rol;
    private final Consumer<String> navegar;
    public PanelAdministracion(Stage owner, String rol, Consumer<String> navegar) { this.owner=owner; this.rol=rol; this.navegar=navegar; }
    public VBox construir() {
        VBox root=new VBox(18); root.setPadding(new Insets(28)); root.setStyle("-fx-background-color:#fbf7fa;");
        Label title=new Label("Configuración y catálogos"); title.setFont(Font.font("System",FontWeight.BOLD,24)); title.setStyle("-fx-text-fill:#51233f;");
        Label sub=new Label("Estos datos se configuran cuando cambia la organización; no hace falta tenerlos siempre a la vista."); sub.setWrapText(true); sub.setStyle("-fx-text-fill:#766572;");
        TilePane grid=new TilePane(); grid.setHgap(14); grid.setVgap(14); grid.setPrefTileWidth(240); grid.setPrefTileHeight(105);
        grid.getChildren().add(card("👥","Donantes y destinatarios","Personas, familias e instituciones", "entidades"));
        grid.getChildren().add(card("🏷️","Categorías","Clasificación de los artículos", "categorias"));
        grid.getChildren().add(card("📍","Ubicaciones","Depósitos y lugares donde se guarda el stock", "ubicaciones"));
        if ("ADMINISTRADOR".equalsIgnoreCase(rol)) grid.getChildren().add(card("🔐","Usuarios y permisos","Cuentas de acceso y roles", "usuarios"));
        root.getChildren().addAll(title,sub,grid); return root;
    }
    private VBox card(String icon,String title,String desc,String destino) {
        VBox c=new VBox(8); c.setPadding(new Insets(16)); c.setAlignment(Pos.CENTER_LEFT); c.setStyle("-fx-background-color:white;-fx-background-radius:12px;-fx-border-color:#eee1e9;-fx-border-radius:12px;-fx-cursor:hand;");
        Label i=new Label(icon); i.setStyle("-fx-font-size:22px;"); Label t=new Label(title); t.setFont(Font.font("System",FontWeight.BOLD,14)); t.setStyle("-fx-text-fill:#51233f;"); Label d=new Label(desc); d.setWrapText(true); d.setStyle("-fx-text-fill:#766572;-fx-font-size:11px;"); c.getChildren().addAll(i,t,d);
        c.setOnMouseClicked(e->navegar.accept(destino)); c.setOnMouseEntered(e->c.setStyle("-fx-background-color:#fff5fa;-fx-background-radius:12px;-fx-border-color:#d63384;-fx-border-radius:12px;-fx-cursor:hand;")); c.setOnMouseExited(e->c.setStyle("-fx-background-color:white;-fx-background-radius:12px;-fx-border-color:#eee1e9;-fx-border-radius:12px;-fx-cursor:hand;")); return c;
    }
}
