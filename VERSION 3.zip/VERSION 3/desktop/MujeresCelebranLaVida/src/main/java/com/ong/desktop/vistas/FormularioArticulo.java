package com.ong.desktop.vistas;

import com.ong.desktop.modelos.Articulo;
import com.ong.desktop.modelos.Categoria;
import com.ong.desktop.modelos.Ubicacion;
import com.ong.desktop.servicios.ApiServicio;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.util.List;

/** Formulario de artículo alineado con los campos reales de la base de datos. */
public class FormularioArticulo {
    public interface AlGuardar { void guardar(Articulo articulo); }

    public static void mostrar(Stage padre, Articulo existente, AlGuardar callback) {
        Stage ventana=new Stage(); ventana.initModality(Modality.WINDOW_MODAL); ventana.initOwner(padre);
        ventana.setTitle(existente==null?"Registrar artículo":"Editar artículo");
        ApiServicio api=new ApiServicio();
        GridPane grid=new GridPane(); grid.setPadding(new Insets(20)); grid.setHgap(10); grid.setVgap(10);

        TextField codigo=new TextField(), descripcion=new TextField(), marca=new TextField(), modelo=new TextField(), serie=new TextField(), cantidad=new TextField("1"), minimo=new TextField("0");
        TextArea observaciones=new TextArea(); observaciones.setPrefRowCount(2);
        ComboBox<Categoria> categoria=new ComboBox<>(); categoria.setPrefWidth(230);
        Button nuevaCategoria = new Button("+ Nueva");
        nuevaCategoria.setOnAction(ev -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Nueva categoría");
            dialog.setHeaderText("Crear categoría de inventario");
            dialog.setContentText("Nombre de la categoría:");
            dialog.showAndWait().ifPresent(nombre -> {
                if (nombre == null || nombre.isBlank()) {
                    new Alert(Alert.AlertType.WARNING, "Ingresá un nombre para la categoría.").showAndWait();
                    return;
                }
                try {
                    Categoria nueva = new Categoria();
                    nueva.setNombre(nombre.trim());
                    nueva.setDescripcion("");
                    Categoria guardada = api.crearCategoria(nueva);
                    categoria.getItems().setAll(api.listarCategorias());
                    categoria.getItems().stream().filter(c -> c.getIdCategoria() != null && c.getIdCategoria().equals(guardada.getIdCategoria())).findFirst().ifPresent(categoria::setValue);
                } catch (Exception ex) {
                    new Alert(Alert.AlertType.ERROR, "No se pudo crear la categoría. " + ex.getMessage()).showAndWait();
                }
            });
        });
        HBox categoriaBox = new HBox(6, categoria, nuevaCategoria);
        ComboBox<Ubicacion> ubicacion=new ComboBox<>(); ubicacion.setPrefWidth(230);
        ComboBox<String> condicion=new ComboBox<>(FXCollections.observableArrayList("NUEVO","BUENO","REGULAR","DETERIORADO","MALO","REPARACION")); condicion.setValue("BUENO");
        ComboBox<String> control=new ComboBox<>(FXCollections.observableArrayList("CANTIDAD","INDIVIDUAL")); control.setValue("CANTIDAD");
        ComboBox<String> estado=new ComboBox<>(FXCollections.observableArrayList("DISPONIBLE","REPARACION")); estado.setValue("DISPONIBLE");
        try { categoria.getItems().setAll(api.listarCategorias()); ubicacion.getItems().setAll(api.listarUbicaciones()); }
        catch(Exception ex) { new Alert(Alert.AlertType.ERROR,"No se pudieron cargar categorías y ubicaciones. Verificá la API.\n"+ex.getMessage()).showAndWait(); }
        if(existente!=null) {
            codigo.setText(n(existente.getCodigoInventario())); descripcion.setText(n(existente.getDescripcion()));
            marca.setText(n(existente.getMarca())); modelo.setText(n(existente.getModelo())); serie.setText(n(existente.getNumeroSerie()));
            cantidad.setText(String.valueOf(existente.getCantidad()==null?1:existente.getCantidad())); minimo.setText(String.valueOf(existente.getStockMinimo()==null?0:existente.getStockMinimo()));
            if(existente.getObservaciones()!=null) observaciones.setText(existente.getObservaciones());
            if(existente.getEstadoConservacion()!=null) condicion.setValue(existente.getEstadoConservacion());
            if(existente.getTipoControl()!=null) control.setValue(existente.getTipoControl());
            if(existente.getEstadoActual()!=null) estado.setValue(existente.getEstadoActual());
            for(Categoria c:categoria.getItems()) if(c.getIdCategoria()!=null&&c.getIdCategoria().equals(existente.getIdCategoria())) categoria.setValue(c);
            for(Ubicacion u:ubicacion.getItems()) if(u.getIdUbicacion()!=null&&u.getIdUbicacion().equals(existente.getIdUbicacion())) ubicacion.setValue(u);
        }
        control.valueProperty().addListener((o,a,v)->{if("INDIVIDUAL".equals(v)){cantidad.setText("1");cantidad.setDisable(true);}else cantidad.setDisable(false);});
        if("INDIVIDUAL".equals(control.getValue())) cantidad.setDisable(true);

        int r=0;
        fila(grid,r++,"Código de inventario *",codigo,"Descripción *",descripcion);
        fila(grid,r++,"Categoría *",categoriaBox,"Ubicación *",ubicacion);
        fila(grid,r++,"Marca",marca,"Modelo",modelo);
        fila(grid,r++,"Número de serie",serie,"Condición",condicion);
        fila(grid,r++,"Tipo de control",control,"Cantidad inicial *",cantidad);
        fila(grid,r++,"Estado inicial",estado,"Stock mínimo",minimo);
        grid.add(new Label("Observaciones"),0,r); grid.add(observaciones,1,r,3,1);

        Button guardar=new Button("Guardar artículo"), cancelar=new Button("Cancelar");
        guardar.setDefaultButton(true); cancelar.setCancelButton(true);
        guardar.setOnAction(e->{
            try {
                if(codigo.getText().isBlank()||descripcion.getText().isBlank()) throw new IllegalArgumentException("Completá el código y la descripción.");
                if(categoria.getValue()==null||ubicacion.getValue()==null) throw new IllegalArgumentException("Seleccioná una categoría y una ubicación.");
                int q=Integer.parseInt(cantidad.getText().trim()), m=Integer.parseInt(minimo.getText().trim());
                if(q<0||m<0) throw new IllegalArgumentException("Cantidad y stock mínimo no pueden ser negativos.");
                if("INDIVIDUAL".equals(control.getValue())&&q!=1) throw new IllegalArgumentException("Un artículo de control individual debe tener cantidad 1.");
                Articulo a=new Articulo(); a.setIdArticulo(existente==null?null:existente.getIdArticulo());
                a.setCodigoInventario(codigo.getText().trim()); a.setNombre(descripcion.getText().trim()); a.setDescripcion(descripcion.getText().trim());
                a.setIdCategoria(categoria.getValue().getIdCategoria()); a.setIdUbicacion(ubicacion.getValue().getIdUbicacion());
                a.setMarca(vacioNulo(marca.getText())); a.setModelo(vacioNulo(modelo.getText())); a.setNumeroSerie(vacioNulo(serie.getText()));
                a.setEstadoConservacion(condicion.getValue()); a.setTipoControl(control.getValue()); a.setCantidad(q); a.setEstadoActual(estado.getValue()); a.setStockMinimo(m); a.setObservaciones(vacioNulo(observaciones.getText()));
                callback.guardar(a); ventana.close();
            } catch(Exception ex) { new Alert(Alert.AlertType.WARNING,"Revisá los datos del artículo:\n"+ex.getMessage()).showAndWait(); }
        });
        cancelar.setOnAction(e->ventana.close());
        HBox acciones=new HBox(10,guardar,cancelar); acciones.setPadding(new Insets(10,0,0,0)); grid.add(acciones,0,r+1,4,1);
        ScrollPane scroll=new ScrollPane(grid); scroll.setFitToWidth(true);
        ventana.setScene(new Scene(scroll,800,520)); ventana.showAndWait();
    }
    private static void fila(GridPane g,int r,String l1,javafx.scene.Node n1,String l2,javafx.scene.Node n2){g.add(new Label(l1),0,r);g.add(n1,1,r);g.add(new Label(l2),2,r);g.add(n2,3,r);}
    private static String n(String s){return s==null?"":s;}
    private static String vacioNulo(String s){return s==null||s.isBlank()?null:s.trim();}
}
